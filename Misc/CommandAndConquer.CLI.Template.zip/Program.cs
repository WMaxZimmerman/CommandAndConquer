﻿using CommandAndConquer.CLI.Core;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            Processor.ProcessArguments(args);
        }
    }
}
