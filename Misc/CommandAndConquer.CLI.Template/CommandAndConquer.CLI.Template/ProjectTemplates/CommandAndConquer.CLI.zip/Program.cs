﻿using CommandAndConquer.CLI.Core;

namespace $safeprojectname$
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            Processor.ProcessArguments(args);
        }
    }
}
